$(document).ready( function() {
    app.initialized()
        .then(function(_client) {
          var client = _client;
          client.events.on('app.activated',
            function() {
                $('#apptext').text(` Location1: ${document.referrer}
                                     Location2: ${document.location.href}`)
        });
        client.interface.trigger("showModal", {
            title: "Sample Modal",
            template: "modal.html"
        })
    });
});
